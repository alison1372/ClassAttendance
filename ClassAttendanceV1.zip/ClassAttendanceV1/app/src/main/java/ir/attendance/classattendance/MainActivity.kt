package ir.attendance.classattendance

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val students = mutableListOf<String>()
    private val absent = mutableSetOf<Int>()
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var className: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        className = findViewById(R.id.className)
        val studentName = findViewById<EditText>(R.id.studentName)
        val list = findViewById<ListView>(R.id.studentList)
        adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, students) {
            override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val v = super.getView(position, convertView, parent) as TextView
                v.text = if (absent.contains(position)) "🔴 ${students[position]} — غایب" else "🟢 ${students[position]} — حاضر"
                v.textSize = 18f; v.gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT; v.setPadding(20,20,20,20)
                return v
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ -> if (!absent.add(position)) absent.remove(position); adapter.notifyDataSetChanged() }
        findViewById<Button>(R.id.addStudent).setOnClickListener {
            val n = studentName.text.toString().trim()
            if (n.isNotEmpty()) { students.add(n); studentName.text.clear(); adapter.notifyDataSetChanged() }
        }
        findViewById<Button>(R.id.saveAttendance).setOnClickListener {
            if (className.text.toString().trim().isEmpty()) { Toast.makeText(this,"ابتدا نام کلاس را وارد کنید",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val names = absent.sorted().map { students[it] }
            Toast.makeText(this, "غیبت ثبت شد: ${names.size} نفر", Toast.LENGTH_LONG).show()
            // مرحله بعد: ارسال همین داده‌ها به Firebase و نمایش لحظه‌ای در پنل مدیر.
        }
    }
}
