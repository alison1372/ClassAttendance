plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "ir.attendance.classattendance"; compileSdk = 35
    defaultConfig { applicationId = "ir.attendance.classattendance"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
